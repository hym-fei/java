package inkball;

import processing.core.PApplet;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class SampleTest {

    @Test
    public void simpleTest() {
        App app = new App();
        app.loop();
        PApplet.runSketch(new String[] { "App" }, app);
        app.setup();
        app.delay(1000); // delay is to give time to initialise stuff before drawing begins
    }

    @Test
    public void testBallMovement() {
        App app = new App();
        app.loop();
        PApplet.runSketch(new String[] { "App" }, app);
        app.setup();
        app.delay(1000); // delay is to give time to initialise stuff before drawing begins

        // Create a ball
        Ball ball = new Ball(10, 10, 'b', true);

        // Move the ball
        ball.move(app);

        //Check if the ball has moved
        assertTrue(ball.x != 10);

        assertTrue(ball.y != 10);

        assertTrue(ball.isMove);
    }

    @Test
    public void testBallCollision() {
        // Test the ball's collision detection function to ensure that the ball collides correctly with map elements after the level is loaded
        App app = new App();
        app.loop();
        PApplet.runSketch(new String[] { "App" }, app);
        app.setup();
        app.delay(1000);
        app.loadLevel("level1.json");
        app.spawnBall();
        app.moveBalls();
        app.waitingBalls();
        app.draw();
    }

    @Test
    public void testHoleCollision() {
        // Test the ball's collision with the hole to make sure the ball detects the hole correctly
        App app = new App();
        app.loop();
        PApplet.runSketch(new String[] { "App" }, app);
        app.setup();
        app.delay(1000);
        app.loadLevel("level1.json");
        app.spawnBall();
        app.moveBalls();
        app.waitingBalls();
        app.draw();
        app.loadingHole();
    }

    @Test
    public void testSpawnerCollision() {
        // Test the interaction between the spawner and the ball, making sure the ball is generated from the spawner and moves correctly
        App app = new App();
        app.loop();
        PApplet.runSketch(new String[] { "App" }, app);
        app.setup();
        app.delay(1000);
        app.loadLevel("level1.json");
        app.spawnBall();
        app.moveBalls();
        app.waitingBalls();
        app.draw();
    }

    @Test
    public void testBallCollisionWithLine() {
        // Test the ball for collisions with lines drawn by the player to ensure the ball's speed or direction changes correctly
        App app = new App();
        app.loop();
        PApplet.runSketch(new String[] { "App" }, app);
        app.setup();
        app.delay(1000);
        app.loadLevel("level1.json");
        app.spawnBall();
        app.moveBalls();
        app.waitingBalls();
        app.draw();
        Ball ball = app.ballArrayList.get(0);
        ball.move(app);
    }


    @Test
    public void testIncreaseScore() {
        // Test the score increase function to ensure that the score increases correctly after calling increaseScore()
        App app = new App();
        app.loop();
        PApplet.runSketch(new String[] { "App" }, app);
        app.setup();
        app.delay(1000);
        app.increaseScore();
        assertEquals(10, app.score);
    }

    @Test
    public void testDecreaseScore() {
        // Test the score reduction function to ensure that the score decreases correctly after calling decreaseScore()
        App app = new App();
        app.loop();
        PApplet.runSketch(new String[] { "App" }, app);
        app.setup();
        app.delay(1000);
        app.decreaseScore();
        assertEquals(-5, app.score);
    }

    @Test
    public void testTogglePause() {
        // Test the game pause function and ensure that the game enters the pause state after calling togglePause()
        App app = new App();
        app.loop();
        PApplet.runSketch(new String[] { "App" }, app);
        app.setup();
        app.delay(1000);
        app.togglePause();
        assertTrue(app.isPaused);
    }

    @Test
    public void testResetLevel() {
        // Test the reset level function to ensure that the ball's state is initialized correctly after the level is reset
        App app = new App();
        app.loop();
        PApplet.runSketch(new String[] { "App" }, app);
        app.setup();
        app.delay(1000);
        app.resetLevel();
        assertTrue(!app.ballArrayList.isEmpty());
    }

    @Test
    public void testLoadingBoard() {
        // Test whether the game loads the map correctly, make sure tilesList is loaded successfully
        App app = new App();
        app.loop();
        PApplet.runSketch(new String[] { "App" }, app);
        app.setup();
        app.delay(1000);
        app.loadingBoard();
        assertTrue(app.tilesList.length > 0);
    }

    @Test
    public void testLoadingBall() {
        // Test the ball loading function in the game to ensure that ballArrayList is not empty after loading the level
        App app = new App();
        app.loop();
        PApplet.runSketch(new String[] { "App" }, app);
        app.setup();
        app.delay(1000);
        app.loadLevel("level1.json");
        app.loadingBall();
        assertFalse(app.ballArrayList.isEmpty());
    }

    @Test
    public void testLoadingHole() {
        // Test the loading function of the hole in the game to ensure that the holeArrayList is not empty after loading the level
        App app = new App();
        app.loop();
        PApplet.runSketch(new String[] { "App" }, app);
        app.setup();
        app.delay(1000);
        app.loadLevel("level1.json");
        app.loadingHole();
        assertFalse(app.holeArrayList.isEmpty());
    }

    @Test
    public void testGetBallImage() {
        // Test the function of getting the image resource of the ball according to the type of ball, and ensure that the returned image path is not empty
        App app = new App();
        String ballImage = app.getBallImage('1');
        assertFalse(ballImage.isEmpty());
    }


}