package inkball;
import processing.core.PVector;
import processing.core.PApplet;
import processing.core.PVector;

import java.util.ArrayList;
import java.util.Iterator;


/**
 * Represents a ball in the game.
 * A ball is a movable object that can have different colors, indicated by its type.
 */
public class Ball extends  Sprite {

    /**
     * The velocity vector of the ball.
     */
    public PVector velocity; // 添加速度向量

    /**
     * The radius of the ball.
     */
    public float radius = 8; // 球的半径，用于碰撞检测

    /**
     * Indicates whether the sprite is in motion.
     * If true, the sprite (in this case, a ball) is currently moving.
     */
    public boolean isMove;

    /**
     * Constructs a Ball object.
     *
     * @param x      The x position of the ball.
     * @param y      The y position of the ball.
     * @param type   The type of the ball, which determines its col or.
     * @param isMove Whether the ball is movable.
     */
    // Ball constructor, passing x, y coordinates and type character
    public Ball(int x, int y, char type, boolean isMove) {
        super(x, y, type);
        this.isMove = isMove;
        this.velocity = new PVector(2, 2); // Default velocity vector
    }

    /**
     * Moves the ball based on its velocity.
     *
     * @param app The main application instance.
     * @return True if the ball is removed from the game, false otherwise.
     */
    public boolean move(App app) {
        boolean isRemove = false;
        // Update the ball's coordinates
        x += (int) velocity.x;
        y += (int) velocity.y;
        Iterator<int[]> it = app.drawnLines.iterator();
        while (it.hasNext()) {
            int[] line = it.next();
            PVector p1 = new PVector(line[0], line[1]);
            PVector p2 = new PVector(line[2], line[3]);
            if (handleCollisionWithLine(p1, p2)) {
                it.remove();
            }
        }
        // Collision with the hole
        for (Hole hole : app.holeArrayList) {
            if (hole.isBallInHole(this)) {
                if (hole.getType() == this.getType() || hole.getType() == '0') {
                    // If the color matches or the hole is gray, the ball goes into the hole, scores a point and disappears
                    app.increaseScore();
                    this.isMove = false; // Stop moving
                } else {
                    // Colors don't match, ball respawns
                    this.respawn(app, this);
                    //Deduction
                    app.decreaseScore();
                }
                isRemove = true;
            }
        }
        // Check if there is a collision with the wall Pass the accelerator
        for (int i = 0; i < App.BALL_WIDTH; i++) {
            for (int j = 0; j < App.BALL_HEIGHT; j++) {
                Tile tile = app.tilesList[i][j];
                if (tile.isWall && this.isCollidingWith(tile)) {
                    if(tile.type == '1' || tile.type == '2' || tile.type == '3' || tile.type == '4' || tile.type == '5'){
                        this.type = tile.type;
                    }
                    // If a collision occurs, check which side it collided with and bounce
                    handleWallCollision(tile);
                }else if (tile.isSpeed && this.isCollidingWith(tile)) {
                    // Accelerator
                    velocity.mult(1.1f);
                }
            }
        }
        return isRemove;
    }

    /**
     * Respawns the ball in the waiting ball list.
     *
     * @param app The main application instance.
     * @param ball The ball to be respawned.
     */
    private void respawn(App app, Ball ball) {
        app.waitingBallArrayList.add(ball);
    }

    /**
     * Handles the collision with a wall.
     *
     * @param tile The tile representing the wall.
     */
    private void handleWallCollision(Tile tile) {
        boolean hitVerticalWall = (x > tile.x && x < tile.x + App.CELLSIZE);  // Vertical edges
        boolean hitHorizontalWall = (y > tile.y && y < tile.y + App.CELLSIZE);  // horizontal margins
        PVector normal = new PVector(0, 0);  //customize toolbar...
        if (hitVerticalWall && !hitHorizontalWall) {
            // If it is a vertical collision (left or right edge), the normal vector is horizontal (1, 0) or (-1, 0)
            normal.set(1, 0);  // Assuming a right-side collision, the normal is facing left (that is, the X-axis direction)
        } else if (hitHorizontalWall && !hitVerticalWall) {
            // If it is a horizontal collision (upper and lower boundaries), the normal vector is vertical (0, 1) or (0, -1)
            normal.set(0, 1);  // Assume the collision is on the upper side, and the normal is downward (Y axis direction)
        } else if (hitVerticalWall) {
            // If it is a corner collision, the normal is in the diagonal direction
            normal.set((x < tile.x + App.CELLSIZE / 2) ? -1 : 1, (y < tile.y + App.CELLSIZE / 2) ? -1 : 1); // Corner bounce
        }
        // Normalized normal vector
        normal.normalize();
        // Use the reflection formula to calculate the new speed
        float dotProduct = velocity.dot(normal);  // Calculate the dot product of velocity and normal vector
        PVector reflection = PVector.sub(velocity, PVector.mult(normal, 2 * dotProduct));  // Reflection formula
        // Update the ball's speed to the speed after reflection
        velocity.set(reflection);
    }

    /**
     * Checks if the ball is colliding with a tile.
     *
     * @param tile The tile to check collision with.
     * @return True if the ball is colliding with the tile, false otherwise.
     */
    private boolean isCollidingWith(Tile tile) {
        return x + radius > tile.x && x - radius < tile.x + App.CELLSIZE &&
                y + radius > tile.y && y - radius < tile.y + App.CELLSIZE;
    }

    /**
     * Handles the collision with a line segment.
     *
     * @param p1 The start point of the line segment.
     * @param p2 The end point of the line segment.
     * @return True if the ball is colliding with the line segment, false otherwise.
     */
    public boolean handleCollisionWithLine(PVector p1, PVector p2) {
//        // 计算线段的方向向量
        PVector lineDir = PVector.sub(p2, p1);
        PVector normal = new PVector(-lineDir.y, lineDir.x);  // 计算法向量
        normal.normalize();  // 将法向量归一化
        // 计算球到线段的距离
        PVector ballPos = new PVector(x, y);
        float distToLine = PVector.dist(p1, ballPos) + PVector.dist(p2, ballPos);
        float lineLength = PVector.dist(p1, p2);
        // 如果球与线段发生碰撞（简单的碰撞检测）
        if (distToLine <= lineLength + radius) {
            // 使用反射公式：v = v - 2(v . n)n
            PVector reflection = PVector.sub(velocity, PVector.mult(normal, 2 * velocity.dot(normal)));
            velocity.set(reflection);
            return true;
        }
        return false;
    }

}