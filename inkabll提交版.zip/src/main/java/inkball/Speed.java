package inkball;

public class Speed extends Sprite {

    /**
     * Constructs a Sprite object.
     *
     * @param x    The x index of the sprite (not the pixel position).
     * @param y    The y index of the sprite.
     * @param type The type of sprite.
     */
    public Speed(int x, int y, char type) {
        super(x, y, type);
    }

}
