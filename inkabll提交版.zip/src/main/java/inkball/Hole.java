package inkball;

/**
 * Represents a hole in the game.
 * A hole is a location that can interact with balls of the corresponding color.
 */
public class Hole extends Sprite{

    /**
     * Constructs a Hole object.
     *
     * @param x    The x position of the hole.
     * @param y    The y position of the hole.
     * @param type The type of hole, corresponding to the ball color it interacts with.
     */
    public Hole (int x, int y, char type) {
        super(x, y, type);
    }

    /**
     * Checks if a ball is within the boundaries of the hole.
     *
     * @param ball The ball to check.
     * @return True if the ball is within the hole, false otherwise.
     */
    public boolean isBallInHole(Ball ball) {
        // Assume the center of the hole is (holeX, holeY) and the radius of the hole is holeRadius
        float holeCenterX = this.x + App.CELLSIZE / 2;  // The center X coordinate of the hole
        float holeCenterY = this.y + App.CELLSIZE / 2;  // The center Y coordinate of the hole
        float holeRadius = App.CELLSIZE / 2;  // Assume the hole is a circle with a radius equal to half the width
        // The center point and radius of the sphere
        float ballCenterX = ball.x;
        float ballCenterY = ball.y;
        float ballRadius = ball.radius;
        // Calculate the distance between the center of the ball and the center of the hole
        float distance = dist(ballCenterX, ballCenterY, holeCenterX, holeCenterY);
        // If the distance is less than or equal to the radius of the ball + the radius of the hole, the ball is considered to have entered the hole
        return distance <= (ballRadius + holeRadius);
    }

    /**
     * Calculates the Euclidean distance between two points.
     *
     * @param x1 The x coordinate of the first point.
     * @param y1 The y coordinate of the first point.
     * @param x2 The x coordinate of the second point.
     * @param y2 The y coordinate of the second point.
     * @return The Euclidean distance between the two points.
     */
    public float dist(float x1, float y1, float x2, float y2) {
        return (float) Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
    }
}