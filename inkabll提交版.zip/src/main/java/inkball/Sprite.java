package inkball;

/**
 * Represents a sprite on the game board.
 * A sprite can be a tile, ball, or other object, with its position and type.
 */
public class Sprite {
    /**
     * The x pixel position of the sprite on the game board.
     * This is calculated from the x index provided during initialization.
     */
    public int x;//Here is the position, for example (0, 32) (32, 32) (32, 64), but what is passed in is (0, 0) (0, 1) which is the index

    /**
     * The y pixel position of the sprite on the game board.
     * This is calculated from the y index provided during initialization,
     * accounting for the board's top margin.
     */
    public int y;

    /**
     * The type of the sprite, represented by a character.
     * This type is used to determine the sprite's behavior and appearance.
     */
    public char type;

    /**
     * Constructs a Sprite object.
     *
     * @param x    The x index of the sprite (not the pixel position).
     * @param y    The y index of the sprite.
     * @param type The type of sprite.
     */
    public Sprite(int x , int y , char type) {
        this.x = XIndToPos(x);
        this.y = YIndToPos(y);
        this.type = type;
    }

    /**
     * Converts the x index to a pixel position.
     *
     * @param indX The x index.
     * @return The x pixel position.
     */

    public int XIndToPos(int indX){
        return indX * 32;
    }

    /**
     * Converts the y index to a pixel position, accounting for the board's top margin.
     *
     * @param indY The y index.
     * @return The y pixel position.
     */
    public int YIndToPos(int indY){
        return 64 + indY * 32;
        // Two grids are left for the board, so starting from the third grid, we add 64+32, which is equivalent to the coordinates (0, 3).
    }

    /**
     * Gets the type of sprite.
     *
     * @return The type of sprite.
     */
    public char getType() {
        return type;
    }

    /**
     * Sets the x pixel position of the sprite.
     *
     * @param x The new x pixel position.
     */
    public void setX(int x) {
        this.x = x;
    }

    /**
     * Converts the x pixel position to an x index.
     *
     * @param x The x pixel position.
     * @return The corresponding x index.
     */
    public int xPositionToIndex(int x){
        return (int) x / 32;
    }

    /**
     * Converts the y pixel position to a y index.
     *
     * @param y The y pixel position.
     * @return The corresponding y index.
     */
    public int yPositionToIndex(int y){
        return (int) (y- 64) / 32;
    }

    /**
     * Sets the y pixel position of the sprite.
     *
     * @param y The new y pixel position.
     */
    public void setY(int y) {
        this.y = y;
    }

    /**
     * Returns a string representation of the Sprite object,
     * including its x and y pixel positions and type.
     *
     * @return A string containing the x and y positions and the type of the sprite.
     */
    @Override
    public String toString() {
        return "x: "+x+" y: "+y+" type: "+type;
    }

}