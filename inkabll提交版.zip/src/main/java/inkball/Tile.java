package inkball;

/**
 * Represents a tile on the game board.
 * A tile can be empty, contain a wall, a ball, or a hole.
 */
public class Tile extends Sprite {

    /**
     * Indicates whether the tile is a wall.
     * If true, the tile represents a wall on the game board.
     */
    public boolean isWall = false;

    /**
     * Indicates whether the tile contains a ball.
     * If true, the tile is occupied by a ball.
     */
    public boolean isBall = false;

    /**
     * Indicates whether the tile contains a hole.
     * If true, the tile is a hole that balls can fall into.
     */
    public boolean isHole = false;

    /**
     * Indicates whether the tile is a speed tile.
     * If true, the tile is a speed tile that increases the speed of the ball.
     */
    public boolean isSpeed = false;

    /**
     * Constructs a Tile object with the given coordinates and type.
     *
     * @param x    The x index of the tile on the grid.
     * @param y    The y index of the tile on the grid.
     * @param type The type of tile (wall, ball, hole, etc.).
     */
    public Tile(int x, int y, char type) {
        super(x, y, type);
        switch (type) {
            case 'W':
                this.setWall();
                break;
            case 'B':
                this.setBall();
                break;
            case 'E':
                this.setSpeed();
                break;
            case 'H':
                this.setHole();
                break;
            default:
                break;
        }
    }

    /**
     * Marks this tile as a wall.
     */
    public void setWall(){
        this.isWall = true;
        this.isBall = false;
        this.isHole = false;
        this.isSpeed = false;
    }

    /**
     * Marks this tile as containing a ball.
     */
    public void setBall() {
        this.isBall = true;
        this.isWall = false;
        this.isHole = false;
        this.isSpeed = false;
    }

    /**
     * Marks this tile as containing a hole.
     */
    public void setHole(){
        this.isHole = true;
        this.isWall = false;
        this.isBall = false;
        this.isSpeed = false;
    }

    /**
     * Marks this tile as containing a speed tile.
     */
    public void setSpeed(){
        this.isSpeed = true;
        this.isHole = false;
        this.isWall = false;
        this.isBall = false;
    }
}