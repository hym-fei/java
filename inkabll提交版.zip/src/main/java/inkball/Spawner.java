package inkball;
import java.util.Random;
import java.util.ArrayList;

/**
 * Represents a spawner in the game.
 * A spawner is a tile that generates balls of a certain type at a specific location on the board.
 */
public class Spawner extends Sprite {

    /**
     * Constructs a Spawner object.
     *
     * @param x    The x position of the spawner on the board.
     * @param y    The y position of the spawner on the board.
     * @param type The type of spawner, which determines the type of balls it generates.
     */
    public Spawner (int x, int y, char type) {
        super(x, y, type);
    }

    /**
     * Returns the x position of the spawner on the board.
     *
     * @return The x position of the spawner on the board.
     */
    public int getX() {
        return this.x * App.CELLSIZE;
    }

    /**
     * Returns the y position of the spawner on the board.
     *
     * @return The y position of the spawner on the board.
     */
    public int getY() {
        return this.y * App.CELLHEIGHT;
    }

    /**
     * Spawns a ball of the specified type at the position of the spawner.
     *
     * @param ballArrayList      The list of balls in the game.
     * @param waitingballArrayList The list of balls waiting to be spawned.
     */
    public void spawnerBall(ArrayList<Ball> ballArrayList, ArrayList<Ball> waitingballArrayList) {
        // Get the next ball waiting
        Ball nextBall = waitingballArrayList.get(0);
        // Create a new ball object and place it in the center
        Ball ball = new Ball(x, y, nextBall.getType(), true);
        ball.setX(x);
        ball.setY(y);
        // Adds a ball to the list of balls and removes it from the waiting list
        ballArrayList.add(ball);
        waitingballArrayList.remove(0);
    }
}