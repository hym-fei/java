package inkball;
import processing.core.PApplet;

import processing.core.PImage;
import processing.data.JSONArray;
import processing.data.JSONObject;
import processing.event.KeyEvent;
import processing.event.MouseEvent;

import java.io.*;
import java.util.*;

/**
 * Main class for the Inkball game application.
 * Extends PApplet to leverage Processing for graphics rendering.
 */
public class App extends PApplet {

    /**
     * The width of every cell
     */
    public static final int CELLSIZE = 32;

    /**
     * The height of every cell
     */
    public static final int CELLHEIGHT = 32;

    /**
     * The width of every cell
     */
    public static final int CELLAVG = 32;

    /**
     * The width of the board
     */
    public static int WIDTH = 576;

    /**
     * The height of the board
     */
    public static int HEIGHT = 640;

    /**
     * The height of every ball
     */
    public static final int BALL_HEIGHT = 18;

    /**
     * The width of every ball
     */
    public static final int BALL_WIDTH = 18;

    /**
     * The frame rate of the game, in frames per second (FPS).
     * <p>
     * This constant sets the speed at which the game updates and renders.
     * A higher FPS results in smoother animations, but may require more processing power.
     * The value is set to 30, which is typically a good balance between performance and visual smoothness.
     * </p>
     */
    public static final int FPS = 30;

    /**
     * Path to the configuration file that stores game settings and level data.
     */
    public String configPath;

    /**
     * A random number generator for generating random numbers within the game.
     */
    public static Random random = new Random();

    /**
     * To calculate score
     */
    public int score;

    /**
     * A list of lines drawn on the board, represented as arrays of two points (x1, y1, x2, y2).
     */
    public ArrayList<int[]> drawnLines;

    /**
     * The original background image used for the game board.
     */
    private PImage originalBackground;

    /**
     * A 2D array representing the tiles on the game board.
     */
    public Tile[][] tilesList;

    /**
     * A list to hold all the balls currently on the board.
     */
    public ArrayList<Ball> ballArrayList;

    /**
     * A list of balls that are waiting to be deployed on the board.
     */
    public ArrayList<Ball> waitingBallArrayList;

    /**
     * A list of holes on the game board.
     */
    public ArrayList<Hole> holeArrayList;

    /**
     * A list of spawners on the game board.
     */
    private ArrayList<Spawner> spawnerArrayList;

    /**
     * The remaining time for the current level or game, measured in seconds.
     * This is updated every second in the game loop and decreases as time progresses.
     * When it reaches 0, the game level or session ends.
     */
    private int time;

    /**
     * The timestamp (in milliseconds) of the last time the game updated the timer.
     * Used to track and calculate the passage of real-world time between updates.
     */
    private long lastTime;

    /**
     * The countdown timer for spawning waiting balls, measured in seconds.
     * This float value allows for finer control (tenths of a second) over the spawn timing.
     */
    private float timeCount = 10.0f;

    /**
     * The timestamp (in milliseconds) of the last update to the ball spawn countdown timer.
     * Used to measure the elapsed time between updates to the ball spawn logic.
     */
    private long lastTimeCount;

    /**
     * The starting X-coordinate of the line being drawn.
     */
    private int startX;

    /**
     * The starting Y-coordinate of the line being drawn.
     */
    private int startY;

    /**
     * A list of all the levels available in the game.
     */
    private List<JSONObject> levels;

    /**
     * The current level number being played.
     */
    private int levelNum;

    /**
     * Indicates whether the game is currently paused.
     */
    boolean isPaused = false;

    /**
     * Indicates whether the game has ended.
     */
    boolean isEnd = false;

    /**
     * Indicates whether the current level has been completed.
     */
    boolean levelCompleted = false;

    /**
     * Indicates whether the level has ended.
     */
    boolean levelEnd = false;

    /**
     * Constructs the App class and initializes the path to the config file.
     */
    public App() {
        this.configPath = "config.json";
    }

    /**
     * Configures the size of the game window.
     * This method is required by Processing.
     */
    @Override
    public void settings() {
        size(WIDTH, HEIGHT);
    }

    /**
     * Reads the configuration file (config.json) to initialize the game settings and level data.
     */
    public void readJson() {
        JSONObject config = loadJSONObject(configPath);
        JSONArray jsonArray = config.getJSONArray("levels");
        //save all level
        for (int i = 0; i < jsonArray.size(); i++){
            levels.add(jsonArray.getJSONObject(i));
        }
        levelNum = 0;
        readLevel(0);//loop level, this is the first
    }

    /**
     * Loads a specific level from a JSON file.
     * @param levelNum The index of the level to load.
     */
    public void readLevel(int levelNum){
        JSONObject level = levels.get(levelNum);
        String levelFile = level.getString("layout");
        loadLevel(levelFile);
        time = level.getInt("time");
        JSONArray spawnerBalls = level.getJSONArray("balls");
        for (int i = 0; i < spawnerBalls.size(); i++) {
            String ballColor = spawnerBalls.getString(i);
            switch (ballColor) {
                case "blue":
                    waitingBallArrayList.add(new Ball(0, 0, '2', false));
                    break;
                case "orange":
                    waitingBallArrayList.add(new Ball(0, 0, '1',false));
                    break;
                case "grey":
                    waitingBallArrayList.add(new Ball(0, 0, '0',false));
                    break;
                case "green":
                    waitingBallArrayList.add(new Ball(0, 0, '3',false));
                    break;
                case "yellow":
                    waitingBallArrayList.add(new Ball(0, 0, '4',false));
                    break;
            }
        }
    }

    /**
     * Loads a level from a given file and populates the game board with tiles, balls, and other elements.
     * Each line in the file corresponds to a row on the board, and each character represents a tile or object.
     *
     * @param fileName The file name of the level layout file.
     */
    public void loadLevel(String fileName) {
        try {
            BufferedReader br = new BufferedReader(new FileReader(fileName));
            String line;
            int rowIndex = 0;
            while ((line = br.readLine()) != null) {
                for (int columnIndex = 0; columnIndex < line.length(); columnIndex++) {
                    char c = line.charAt(columnIndex);
                    Tile tile = new Tile(columnIndex, rowIndex, c);
                    tilesList[rowIndex][columnIndex] = tile;
                    if (c == 'B') {
                        char ballType = line.charAt(columnIndex + 1);
                        Ball b = new Ball(columnIndex, rowIndex, ballType,true);
                        ballArrayList.add(b);
                        tile.setBall();
                        columnIndex ++;//skip next char,because ball
                        // 获取右边格子并设置为普通 tile
                        if (columnIndex < line.length()) {
                            Tile rightTile = new Tile(columnIndex, rowIndex, 'T');  //normal tile
                            tilesList[rowIndex][columnIndex] = rightTile;  // set the right cell as a normal tile
                        }
                    } else if (c == 'E') {
                        tilesList[rowIndex][columnIndex].setSpeed();
                    } else if (c == 'H') {
                        Hole h = new Hole(columnIndex, rowIndex, line.charAt(columnIndex + 1));
                        holeArrayList.add(h);
                        tile.setHole();
                        columnIndex ++;//skip next char,because hole
                        if (columnIndex < line.length()) {
                            Tile rightTile = new Tile(columnIndex, rowIndex, 'H');
                            rightTile.setHole();
                            tilesList[rowIndex][columnIndex] = rightTile;
                        }
                    } else if (c == 'S') {
                        Spawner s = new Spawner(columnIndex, rowIndex, line.charAt(columnIndex));
                        spawnerArrayList.add(s);
                    } else if (c == 'X' || c == '1' || c == '2' || c == '3' || c == '4') {
                        tilesList[rowIndex][columnIndex].setWall();
                    }
                }
                rowIndex++;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Sets up the game components such as tiles, balls, and spawners.
     * It initializes the game window and reads the configuration.
     */
    @Override
    public void setup() {
        frameRate(FPS);
        tilesList = new Tile[BALL_WIDTH][BALL_HEIGHT];
        ballArrayList = new ArrayList<>();
        holeArrayList = new ArrayList<>();
        spawnerArrayList = new ArrayList<>();
        waitingBallArrayList = new ArrayList<>();
        drawnLines = new ArrayList<>();
        levels = new ArrayList<>();
        readJson();
        originalBackground = get();
        score = 0;
        lastTime = millis();
        lastTimeCount = millis();
    }

    /**
     * Loads the board, drawing all the tiles on the screen.
     * Tiles may include empty spaces, walls, entry points, and holes.
     */
    public void loadingBoard() {
        for (int rowIndex = 0; rowIndex < 18; rowIndex++) {
            for (int columnIndex = 0; columnIndex < 18; columnIndex++) {
                Tile tile = tilesList[columnIndex][rowIndex];
                String imageResource = "inkball/tile.png";
                if (!tile.isBall) {
                    if (tile.getType() == 'X') {
                        imageResource = "inkball/wall0.png";
                    } else if (tile.getType() == '1') {
                        imageResource = "inkball/wall1.png";
                    } else if (tile.getType() == '2') {
                        imageResource = "inkball/wall2.png";
                    } else if (tile.getType() == '3') {
                        imageResource = "inkball/wall3.png";
                    } else if (tile.getType() == '4') {
                        imageResource = "inkball/wall4.png";
                    } else if (tile.getType() == 'E') {
                        imageResource = "inkball/ex.png";
                    } else if (tile.getType() == 'S') {
                        imageResource = "inkball/entrypoint.png";
                    } else if (tile.getType() == 'H') {
                        tile.setHole();
                    }
                    PImage img = loadImage(imageResource);
                    if (img == null) {
                        System.out.println("Failed to load image: " + imageResource);
                    } else {
                        image(img, tile.x, tile.y);
                    }
                }else{
                    PImage img = loadImage(imageResource);
                    image(img, tile.x, tile.y);
                }
            }
        }
    }

    /**
     * Loads and draws all the holes on the game board.
     * Holes are locations where balls of a corresponding color can interact.
     */
    public void loadingHole() {
        for (Hole hole : holeArrayList) {
            String imageResource = "inkball/hole" + hole.getType() + ".png";
            PImage img = loadImage(imageResource);
            if (img == null) {
                System.out.println("Failed to load image: " + imageResource);
            } else {
                image(img, hole.x, hole.y);
            }
        }
    }

    /**
     * Returns the image resource corresponding to the ball type.
     *
     * @param type The type of ball (which corresponds to its color).
     * @return The image resource path for the ball.
     */
    public String getBallImage(char type) {
        int typeNumber = Character.getNumericValue(type);
        if (typeNumber >= 0 && typeNumber <= 4) {
            return "inkball/ball" + typeNumber + ".png";
        } else {
            return "inkball/tile.png";
        }
    }

    /**
     * Loads and draws all the balls on the game board.
     * Balls are displayed on top of their corresponding tiles.
     */
    public void loadingBall() {
        for (Ball ball : ballArrayList) {
            String ballSource = getBallImage(ball.getType());
            PImage img = loadImage(ballSource);
            if (img == null) {
                System.out.println("Failed to load image: " + ballSource);
            } else {
                image(img, ball.x, ball.y);
            }
        }
    }

    /**
     * Displays the score and remaining time on the top of the screen.
     * It updates the timer and ensures that time is not negative.
     */
    public void loadingBar() {
        fill(0); // use black
        textSize(25);
        text("Score: " + score, 440, 33);
        text("Time: " + time, 440, 55);
        long currentTime = millis();
        if (currentTime - lastTime >= 1000) {
            if (time > 0) {  // avoid minus count problem
                time -= 1;
            }else{
                isEnd = true;
            }
            lastTime = currentTime;
        }
    }

    /**
     * Loads and displays the balls waiting to be spawned.
     * Displays a countdown timer for spawning the next ball.
     */
    public void waitingBalls() {
        fill(0);
        rect(10, 16, 158, 31);
        fill(0);
        textSize(25);
        if (!waitingBallArrayList.isEmpty()) {
            text(String.format("%.1f", timeCount), 188, 41);
            long currentTime = millis();
            if (currentTime - lastTimeCount >= 100) {
                timeCount -= 0.1f;
                if (timeCount <= 0.0f) {
                    timeCount = 10.0f;
                    spawnBall();
                }
                lastTimeCount = currentTime;
            }
            int size = Math.min(waitingBallArrayList.size(), 5);
            int rowIndex = 12;
            for (int i = 0; i < size; i++) {
                Ball ball = waitingBallArrayList.get(i);
                String ballImage = getBallImage(ball.getType());
                PImage img = loadImage(ballImage);
                //every ball appear gradually, move to the target
                image(img, rowIndex, 18);
                rowIndex += 32;
            }
        }
    }

    /**
     * Moves all the balls in the game board.
     * Checks for collisions and handles them accordingly.
     */
    public void moveBalls() {
        Iterator<Ball> it = ballArrayList.iterator();
        while (it.hasNext()) {
            Ball ball = it.next();
            boolean move = ball.move(this);
            if (move) {
                it.remove();
            }
        }
    }

    /**
     * Toggles the pause state of the game.
     * If the game is paused, it will be resumed.
     * If the game is not paused, it will be paused.
     */
    public void togglePause() {
        isPaused = !isPaused;
        if (isPaused) {
            textSize(20);
            fill(255, 0, 0);
            text("*** PAUSED ***", 250, 40);
            noLoop();  // stop draw()
        } else {
            loop();  // recover draw()
        }
    }

    /**
     * Handles key press events in the game.
     * If the 'r' or 'R' key is pressed, it resets the level.
     * If the spacebar is pressed, it toggles the pause state of the game.
     *
     * @param event The KeyEvent object representing the key press event.
     */
    @Override
    public void keyPressed(KeyEvent event) {
        if (event.getKey() == 'r' || event.getKey() == 'R') {
            // reset the game
            resetLevel();
            isEnd = false;
        } else if (event.getKey() == ' ') {  // pause ' ' to stop
            togglePause();
        }
    }

    /**
     * Handles mouse press events in the game.
     * If the left mouse button is pressed, it starts drawing a line segment.
     * If the right mouse button is pressed, it clears the drawn lines.
     *
     * @param e The MouseEvent object representing the mouse press event.
     */
    @Override
    public void mouseReleased(MouseEvent e) {
        if (e.getButton() == LEFT) {
            //left button release to stop drawing
            //When the mouse is released, the end point of the line segment is recorded and added to drawnLines
            int endX = mouseX;
            int endY = mouseY;
            // Add complete line segment start and end coordinates
            drawnLines.add(new int[]{startX, startY, endX, endY});
        } else if (e.getButton() == RIGHT) {
            // Release the right button to clear the drawn line
            drawnLines.clear();
        }
    }

    /**
     * Resets the game level by clearing all balls, waiting balls, and drawn lines.
     * It also resets the score, time, and other game states.
     */
    public void resetLevel() {
        // Reset the level logic, clear all states, and restart the game
        ballArrayList.clear();
        waitingBallArrayList.clear();
        drawnLines.clear();
        score = 0;
        time = 120;
        setup();  // reset
    }

    /**
     * Handles mouse press events in the game.
     * If the left mouse button is pressed, it starts drawing a line segment.
     * If the right mouse button is pressed, it clears the drawn lines.
     *
     * @param e The MouseEvent object representing the mouse press event.
     */
    @Override
    public void mousePressed(MouseEvent e) {
        if (mouseButton == LEFT) {
            // When the mouse is pressed, record the starting point of the line segment
            startX = mouseX;
            startY = mouseY;
        }else if (mouseButton == RIGHT) {
            drawnLines.clear();  // delete all the lines
        }
    }

    /**
     * Draws the lines drawn by the player.
     */
    public void drawLines() {
        stroke(0);
        strokeWeight(10);  // width
        for (int[] line : drawnLines) {
            line(line[0], line[1], line[2], line[3]);  // Draw a line using the line() function in Processing
        }
    }

    /**
     * Spawns a ball from a random spawner in the game board.
     */
    public void spawnBall() {
        // Randomly select a spawner from the spawnerArrayList
        if (!spawnerArrayList.isEmpty()) {
            Spawner randomSpawner = spawnerArrayList.get(random.nextInt(spawnerArrayList.size()));
            // Randomly generate the ball's initial velocity
            randomSpawner.spawnerBall(ballArrayList, waitingBallArrayList);
        }
    }

    /**
     * Main drawing loop for the game.
     * Called repeatedly by Processing to render the game frame by frame.
     */
    @Override
    public void draw() {
        if (isPaused) {
            textSize(20);
            fill(255, 0, 0);
            // Displays the paused state and does not execute game logic
            text("*** PAUSED ***", 250, 40);
            return;  // Return directly to avoid executing the following logic
        }
        if (isEnd) {
            textSize(20);
            fill(255, 0, 0);
            text("===ENDED ===", 250, 40);
            return;
        }
        if(levelEnd){
            textSize(20);
            fill(255, 0, 0);
            text("===ENDED ===", 250, 40);
            return;
        }
        if (levelCompleted) {
            nextLevel();
            return;
        }
        background(255);
        loadingBoard();  // Load the background first
        loadingHole();   // Reload the hole
        drawLines();  // Draw the player's line segment
        moveBalls();  // Moving the ball and handling collisions
        loadingBall();   // Reload the ball (make sure the ball is displayed above the background)
        loadingBar();    // Loading top score and time bar
        waitingBalls();  // Loading waiting ball
        checkLevelComplete();
    }

    /**
     * Main method to start the game.
     * Initializes the game and starts the Processing application.
     *
     * @param args Command-line arguments (not used).
     */
    public static void main(String[] args) {
        PApplet.main("inkball.App");
    }

    /**
     * Increases the player's score by a fixed amount.
     */
    public void increaseScore() {
        int scoreIncrease = 10;
        score += scoreIncrease;
        System.out.println("Score increased by " + scoreIncrease + ". Current score: " + score);
    }

    /**
     * Decreases the player's score by a fixed amount.
     */
    public void decreaseScore() {
        int scoreDecrease = 5;
        score -= scoreDecrease;
        System.out.println("Score decreased by " + scoreDecrease + ". Current score: " + score);
    }

    /**
     * Checks if the game level is completed.
     * If all balls and waiting balls are removed, the level is considered completed.
     */
    public void checkLevelComplete() {
        levelCompleted = ballArrayList.isEmpty() && waitingBallArrayList.isEmpty();
    }

    /**
     * Moves the balls and handles collisions between them and the walls and holes.
     */
    public void nextLevel() {
        levelCompleted = false;
        frameRate(FPS);
        tilesList = new Tile[BALL_WIDTH][BALL_HEIGHT];
        ballArrayList = new ArrayList<>();
        holeArrayList = new ArrayList<>();
        spawnerArrayList = new ArrayList<>();
        waitingBallArrayList = new ArrayList<>();
        drawnLines = new ArrayList<>();
        if(levelNum < levels.size()){
            readLevel(++levelNum);
        }else{
            levelEnd = true;
        }
        originalBackground = get();
        lastTime = millis();
        lastTimeCount = millis();
    }
}